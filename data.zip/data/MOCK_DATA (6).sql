insert into department (DepartmentID, DepartmentName, Location) values (1, 'فنی و مهندسی', '946 Prairieview Parkway');
insert into department (DepartmentID, DepartmentName, Location) values (2, 'علوم پایه', '33 Tomscot Crossing');
insert into department (DepartmentID, DepartmentName, Location) values (3, 'ادبیات', '5811 La Follette Park');
insert into department (DepartmentID, DepartmentName, Location) values (4, 'هنر', '89643 Pennsylvania Avenue');
insert into department (DepartmentID, DepartmentName, Location) values (5, 'کشاورزی', '3631 Kennedy Crossing');
insert into department (DepartmentID, DepartmentName, Location) values (6, 'تربیت بدنی', '984 Ryan Street');
